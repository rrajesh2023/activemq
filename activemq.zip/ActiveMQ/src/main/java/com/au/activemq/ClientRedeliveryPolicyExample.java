package com.au.activemq;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;

import javax.jms.*;

public class ClientRedeliveryPolicyExample {

	private final static String WIRE_LEVEL_ENDPOINT = "ssl://b-6d30ea80-763d-4cde-a966-de5b9e02d885-1.mq.ap-southeast-2.amazonaws.com:61617";
	private final static String ACTIVE_MQ_USERNAME = "admin";
	private final static String ACTIVE_MQ_PASSWORD = "password1234";
	private static final String QUEUE_NAME = "MyQueue";
    


	private static ActiveMQConnectionFactory createActiveMQConnectionFactory() {
		// Create a connection factory.
		final ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(WIRE_LEVEL_ENDPOINT);

		// Pass the sign-in credentials.
		connectionFactory.setUserName(ACTIVE_MQ_USERNAME);
		connectionFactory.setPassword(ACTIVE_MQ_PASSWORD);
		return connectionFactory;
	}

    public static void main(String[] args) {
    	
    	

        Connection connection = null;
        Session session = null;
        MessageConsumer consumer = null;

        try {
        	final ActiveMQConnectionFactory connectionFactory = createActiveMQConnectionFactory();
            // Create connection factory
            //ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);

            // Create connection
            connection = connectionFactory.createConnection();
            connection.start();

            // Create session
            session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);

            // Create queue
            Queue queue = session.createQueue(QUEUE_NAME);

            // Create consumer
            consumer = session.createConsumer(queue);

            // Set redelivery policy for the consumer
            RedeliveryPolicy redeliveryPolicy = new RedeliveryPolicy();
            redeliveryPolicy.setMaximumRedeliveries(3); // Maximum number of redelivery attempts
            ((ActiveMQConnectionFactory) connectionFactory).setRedeliveryPolicy(redeliveryPolicy);

            // Start consuming messages
            while (true) {
                Message message = consumer.receive(); // Blocking call to receive a message

                // Handle message
                if (message instanceof TextMessage) {
                    TextMessage textMessage = (TextMessage) message;
                    try {
                        // Process message
                        System.out.println("Received message: " + textMessage.getText());
                        System.out.println("Received message: " + textMessage.getJMSRedelivered());
                        System.out.println("Received message: " + textMessage.toString());

                        // Simulate processing failure
                        throw new RuntimeException("Simulated processing failure");
                    } catch (Exception e) {
                        // Handle processing failure

                        // Log the error
                        System.err.println("Error processing message: " + e.getMessage());

                        // No need for additional redelivery logic here, as it's handled by the redelivery policy
                    }
                }
            }
        } catch (JMSException e) {
            e.printStackTrace();
        } finally {
            // Clean up resources
            try {
                if (consumer != null) {
                    consumer.close();
                }
                if (session != null) {
                    session.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (JMSException e) {
                e.printStackTrace();
            }
        }
    }
}
